// TODO

// for (....) {
#ifdef VIEW_COMPACT_USE_ZERO
// std::cout << '0';
#else
// std::cout << 'O';
#endif
// }

// TODO
