#include <vector>

namespace lab_bigint {

class bigint {
};

}  // namespace lab_bigint
