[Оценки](https://docs.google.com/spreadsheets/d/1t5rn3SiJGOBlMb1BMrJRniI4AId_Zqo25QrYWas5cqg) доступны только когда вы залогинились в Google Account, который участвует в рассылке.
Если у вас не Gmail, то вы всё ещё можете создать Google Account с другой почтой — вот в него и надо заходить.

Индивидуально доступ выдаваться не будет.
Только через список рассылки.
