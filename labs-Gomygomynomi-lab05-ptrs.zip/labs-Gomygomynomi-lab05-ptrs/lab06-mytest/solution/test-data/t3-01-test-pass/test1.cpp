#include "mytest.hpp"

TEST_CASE("Test1.cpp test case 1") {
    CHECK(2 * 2 == 4);
}

TEST_CASE("Test1.cpp test case 2") {
    CHECK(2 * 3 == 6);
}
